import streamlit as st
import pandas as pd
import numpy as np 
from PIL import Image 
import datetime
from streamlit_option_menu import option_menu
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
import statsmodels.api as sm
import plotly.graph_objects as go


def myColors():
        global color_discrete_sequence
        color_discrete_sequence = ['#ec7c23']*len(df)
        for i in range (len(df)):
                color_discrete_sequence[0] = '#FFFF00' 
                color_discrete_sequence[1] = '#CC0033'
                color_discrete_sequence[2] = '#FF66CC'
                color_discrete_sequence[3] = '#3300FF'
                color_discrete_sequence[2] = '#33CCCC'
                color_discrete_sequence[5] = '#00FF66'
                color_discrete_sequence[6] = '#434a11' 
                color_discrete_sequence[7] = '#CC0033'
                color_discrete_sequence[8] = '#CCFF00'
                color_discrete_sequence[9] = '#9933000'
                color_discrete_sequence[10] = '#FF3300'
                color_discrete_sequence[11] = '#32CD32'


st.set_page_config(layout='wide')
diamonds = pd.read_csv(r"D:\Programy\Uczelnia\Python\PAD_PD_s16786_2024_02_03\PAD_PD_s16786\orca_uzup.csv")
df = diamonds.copy()

df_without_column0 = df.drop(columns=["Unnamed: 0"])
df =df_without_column0

#1. sidebar menu

#with st.sidebar:
selected = option_menu(
    menu_title= 'Main Menu',
    options= ['Zależność od Ceny','Rozkład zmiennych', 'Liczebność w kolumnach' ,'Model regresji'],
    icons= ['house','book','cloud','clock'],
    menu_icon= 'cast',
    default_index= 0,
    orientation='horizontal'    
)
##################### Home
if selected == 'Zależność od Ceny':
        #st.title(f" Wybrałeś stronę {selected} /n Zródło danych:")
        st.header('Diamonds Statistic')
        df
        page = st.sidebar.selectbox('Zależność od Ceny',['carat, color, cut /price /clarity','x, y, z /price /clarity','clarity, color /price /color']) 

        if page == 'carat,color,cut / price':
                clist = df['clarity'].unique()
                clarity = st.selectbox("Select  clarity",clist)
                
                col1, col2, col3 = st.columns(3)
                
                fig  = px.line(df[df['clarity'] == clarity],
                #fig  = px.line(df,
                        x = 'price', y = 'carat', title='Price / carat')
                col1.plotly_chart(fig,use_container_width=True)
                
                fig  =px.line(df[df['clarity'] == clarity],
                #fig  =px.line(df,              
                x = 'price', y = 'color', title='Price / color')
                col2.plotly_chart(fig,use_container_width=True)
                
                fig  =px.line(df[df['clarity'] == clarity],
                #fig  =px.line(df,              
                x = 'price', y ='cut', title='Price / cut')
                col3.plotly_chart(fig,use_container_width=True)

        if page == 'x,y,z / price':
                clist = df['clarity'].unique()
                clarity = st.selectbox("Select  clarity",clist)
                
                col1, col2, col3 = st.columns(3)
                
                fig  = px.line(df[df['clarity'] == clarity],
                #fig  = px.line(df,
                        x = 'price', y = 'x', title='Price / x')
                col1.plotly_chart(fig,use_container_width=True)
                
                fig  =px.line(df[df['clarity'] == clarity],
                #fig  =px.line(df,              
                x = 'price', y = 'y', title='Price / y')
                col2.plotly_chart(fig,use_container_width=True)
                
                fig  =px.line(df[df['clarity'] == clarity],
                #fig  =px.line(df,              
                x = 'price', y ='z', title='Price / z')
                col3.plotly_chart(fig,use_container_width=True)    

        elif page == 'table from price':
                
                clist= df['table'].unique()
                tabledata= st.selectbox("Select  table",clist)

                col1, col2= st.columns(2)
                
                fig  = px.line(df[df['table'] == tabledata],
                        x = 'price', y = 'carat', title='Price per carat')
                col1.plotly_chart(fig,use_container_width=True)
                
                fig  =px.line(df[df['table'] == tabledata],
                #fig  =px.line(df,              
                x = 'price', y = 'color', title='Price per color')
                col2.plotly_chart(fig,use_container_width=True)
                
        elif page == 'carat from price':    
                clist= df['carat'].unique()
                tabledata= st.selectbox("Select  carat",clist)
                col1, col2= st.columns(2)               
                fig  = px.line(df[df['carat'] == tabledata],
                        x = 'price', y = 'clarity', title='Price per clarity')
                col1.plotly_chart(fig)               
                fig  =px.line(df[df['carat'] == tabledata],
                #fig  =px.line(df,              
                x = 'price', y = 'color', title='Price per color')
                col2.plotly_chart(fig)
        else:    
                st.write("Wizualizacja rozkładu zmiennych")


        
        
        
#####################  Rozkład zmiennych       
if selected == 'Rozkład zmiennych':
        st.title(f" Wizualizacja rozkładu zmiennych")  

        page1 = st.sidebar.selectbox('Liczebność zmiennych',['liczebność carat','liczebność clarity','liczebność color','liczebność cut','liczebność x dimension',
                                'liczebność y dimension','liczebność z dimension','liczebność depth','liczebność table' ,'liczebność price']) 
        df3=df.copy()
        ############ page1
        if page1 == 'liczebność carat':
                category_counts1 = df['carat'].value_counts().reset_index() 
                category_counts1.columns = ['carat','Count']
                unique_values = df['carat'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)

                fig = px.bar(category_counts1,x = 'carat', y = 'Count', color= 'carat', color_continuous_scale = 'viridis', labels= {'carat': 'carat', 'Count' : 'liczebność'},
                                barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
                #fig.show()
                st.plotly_chart(fig,use_container_width=True)

        elif page1 == 'liczebność clarity':

                category_counts1 = df['clarity'].value_counts().reset_index() 
                category_counts1.columns = ['clarity','Count']
                unique_values = df['clarity'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)
                myColors()
                fig = px.bar(category_counts1,x = 'clarity', y = 'Count', color= 'clarity', color_discrete_sequence=color_discrete_sequence, labels= {'clarity': 'clarity', 'Count' : 'liczebność'},
                        barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
                #fig.show()
                st.plotly_chart(fig,use_container_width=True)

        elif page1 == 'liczebność color':
                
                category_counts1 = df['color'].value_counts().reset_index() 
                category_counts1.columns = ['color','Count']
                unique_values = df['color'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)
                myColors()
                fig = px.bar(category_counts1,x = 'color', y = 'Count', color= 'color', color_discrete_sequence=color_discrete_sequence, labels= {'color': 'color', 'Count' : 'liczebność'},
                                barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
                st.plotly_chart(fig,use_container_width=True)

        elif page1 == 'liczebność cut':
                
                category_counts1 = df['cut'].value_counts().reset_index() 
                category_counts1.columns = ['cut','Count']
                unique_values = df['cut'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)
                myColors()
                fig = px.bar(category_counts1,x = 'cut', y = 'Count', color= 'cut', color_discrete_sequence=color_discrete_sequence, labels= {'cut': 'cut', 'Count' : 'liczebność'},
                                barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')  
                st.plotly_chart(fig,use_container_width=True)

        if page1 == 'liczebność x dimension':

                category_counts1 = df['x'].value_counts().reset_index() 
                category_counts1.columns = ['x','Count']
                unique_values = df['x'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)

                fig = px.bar(category_counts1,x = 'x', y = 'Count', color= 'x', color_continuous_scale = 'viridis', labels= {'x': 'x', 'Count' : 'liczebność'},
                                barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')

                st.plotly_chart(fig,use_container_width=True)

        if page1 == 'liczebność y dimension':

                category_counts1 = df['y'].value_counts().reset_index() 
                category_counts1.columns = ['y','Count']
                unique_values = df['y'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)
                fig = px.bar(category_counts1,x = 'y', y = 'Count', color= 'y', color_continuous_scale = 'viridis', labels= {'y': 'y', 'Count' : 'liczebność'},
                                barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')  
                st.plotly_chart(fig,use_container_width=True)
        if page1 == 'liczebność z dimension':

                category_counts1 = df['z'].value_counts().reset_index() 
                category_counts1.columns = ['z','Count']
                unique_values = df['z'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)
                fig = px.bar(category_counts1,x = 'z', y = 'Count', color= 'z', color_continuous_scale = 'viridis', labels= {'z': 'z', 'Count' : 'liczebność'},
                                barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
                st.plotly_chart(fig,use_container_width=True)      

        if page1 == 'liczebność depth':

                category_counts1 = df['depth'].value_counts().reset_index() 
                category_counts1.columns = ['depth','Count']
                unique_values = df['depth'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)
                fig = px.bar(category_counts1,x = 'depth', y = 'Count', color= 'depth', color_continuous_scale = 'viridis', labels= {'depth': 'depth', 'Count' : 'liczebność'},
                                barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
                #fig.show()   
                st.plotly_chart(fig,use_container_width=True)    

        if page1 == 'liczebność table':
                
                category_counts1 = df['table'].value_counts().reset_index() 
                category_counts1.columns = ['table','Count']
                unique_values = df['table'].nunique()
                st.write(" Liczebność kategorii : ", unique_values)

                fig = px.bar(category_counts1, x = 'table', y = 'Count', color= 'table', color_continuous_scale = 'viridis', labels= {'table': 'table', 'Count' : 'liczebność'},
                                barmode='stack', text_auto=True ) 
                fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')   
                st.plotly_chart(fig,use_container_width=True)    

        if page1 == 'liczebność price':

                        category_counts1 = df['price'].value_counts().reset_index() 
                        category_counts1.columns = ['price','Count']
                        unique_values = df['price'].nunique()
                        st.write(" Liczebność kategorii : ", unique_values)
                        myColors()
                        fig = px.bar(category_counts1,x = 'price', y = 'Count', color= 'price', color_continuous_scale = 'viridis', labels= {'price': 'price', 'Count' : 'liczebność'},
                                        barmode='stack', text_auto=True ) 
                        fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside') 
                        st.plotly_chart(fig,use_container_width=True)      


#####################  Liczebność w kolumnach        
              
if selected == 'Liczebność w kolumnach':
        myColors()
        fig = px.bar(df.nunique(), x=df.columns, y=df.nunique(), color = df.columns, color_continuous_scale = 'viridis', title='Liczebność w kolumnach',
                labels= {'index': 'kolumny', 'y' : 'liczebność'},barmode='stack', text_auto=True ) 
        fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
        st.plotly_chart(fig,use_container_width=True)

#####################  Model regresji       
              
if selected == 'Model regresji':

        st.title("Wizualizacja modelu regresji")
        model2 = smf.ols(formula="price ~ carat", data=df).fit()
        #st.write(" fkdsafk", {model2})
        df['fitted'] = model2.fittedvalues
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df['carat'], y=df['price'], mode='markers'))
        fig.add_trace(go.Scatter(x=df['carat'], y=df['fitted']))
        st.plotly_chart(fig,use_container_width=True) 




