import streamlit as st
import pandas as pd
import numpy as np 
from PIL import Image 
import datetime
from streamlit_option_menu import option_menu
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt









#selected = option_menu(
 #   menu_title= None ,
  #  options= ['Home','Histogram analysis', 'Other'],
   # icons= ['house','book','envelope'],
    #menu_icon= 'cast',
    #default_index= 1,
    #orientation='horizontal'    
#)

#st.title("Tytuł mojego dashbordu")

#st.header("nagłówek")
#st.text("zwykły text")

#st.markdown("## this is markdown 2 level")
#st.success("Udało się")
#status = st.radio("Wybierz stus", ("Akty", "nie akty"))

st.set_page_config(layout='wide')
# data =st.file_uploader("tu wrzuc swoje dane", type=['csv'])
# if data is not None: 
#     df = pd.read_csv(data)
#     st.dataframe(df) 
diamonds = pd.read_csv(r"C:\Users\handl\Desktop\python lukasz\PAD_PD_s16786\orca_uzup.csv")
df = diamonds.copy()
df.head(10)


#df = df.DataFrame(df)
st.write("Wizualizacja rozkładu zmiennych")
st.header('Diamonds Statistic')

page = st.sidebar.selectbox('Zależność od Ceny',['carat,color,cut / price','x,y,z / price','carat from price']) 


if page == 'carat,color,cut / price':
    clist = df['clarity'].unique()
    clarity = st.selectbox("Select  clarity",clist)
    
    col1, col2, col3 = st.columns(3)
    
    fig  = px.line(df[df['clarity'] == clarity],
    #fig  = px.line(df,
        x = 'price', y = 'carat', title='Price / carat')
    col1.plotly_chart(fig,use_container_width=True)
    
    fig  =px.line(df[df['clarity'] == clarity],
    #fig  =px.line(df,              
       x = 'price', y = 'color', title='Price / color')
    col2.plotly_chart(fig,use_container_width=True)
    
    fig  =px.line(df[df['clarity'] == clarity],
    #fig  =px.line(df,              
       x = 'price', y ='cut', title='Price / cut')
    col3.plotly_chart(fig,use_container_width=True)

if page == 'x,y,z / price':
    clist = df['clarity'].unique()
    clarity = st.selectbox("Select  clarity",clist)
    
    col1, col2, col3 = st.columns(3)
    
    fig  = px.line(df[df['clarity'] == clarity],
    #fig  = px.line(df,
        x = 'price', y = 'x', title='Price / x')
    col1.plotly_chart(fig,use_container_width=True)
    
    fig  =px.line(df[df['clarity'] == clarity],
    #fig  =px.line(df,              
       x = 'price', y = 'y', title='Price / y')
    col2.plotly_chart(fig,use_container_width=True)
    
    fig  =px.line(df[df['clarity'] == clarity],
    #fig  =px.line(df,              
       x = 'price', y ='z', title='Price / z')
    col3.plotly_chart(fig,use_container_width=True)    

elif page == 'table from price':
   
    clist= df['table'].unique()
    tabledata= st.selectbox("Select  table",clist)

    col1, col2= st.columns(2)
    
    fig  = px.line(df[df['table'] == tabledata],
        x = 'price', y = 'carat', title='Price per carat')
    col1.plotly_chart(fig,use_container_width=True)
    
    fig  =px.line(df[df['table'] == tabledata],
    #fig  =px.line(df,              
       x = 'price', y = 'color', title='Price per color')
    col2.plotly_chart(fig,use_container_width=True)
    
elif page == 'carat from price':    
    clist= df['carat'].unique()
    tabledata= st.selectbox("Select  carat",clist)

    col1, col2= st.columns(2)
    
    fig  = px.line(df[df['carat'] == tabledata],
        x = 'price', y = 'clarity', title='Price per clarity')
    col1.plotly_chart(fig)
    
    fig  =px.line(df[df['carat'] == tabledata],
    #fig  =px.line(df,              
       x = 'price', y = 'color', title='Price per color')
    col2.plotly_chart(fig)
else:    
    st.write("Wizualizacja rozkładu zmiennych")
    
    
    
    
page1 = st.sidebar.selectbox('Liczebność zmiennych',['liczebność carat','liczebność clarity','liczebność color','liczebność cut','liczebność x dimension',
                              'liczebność y dimension','liczebność z dimension','liczebność depth','liczebność table' ,'liczebność price']) 
    
############ page1
if page1 == 'liczebność carat':
    
    category_counts1 = df['carat'].value_counts().reset_index() 
    category_counts1.columns = ['carat','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'carat', y = 'Count', color= 'carat', color_continuous_scale = 'viridis', labels= {'carat': 'carat', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()

elif page1 == 'liczebność clarity':
    
    category_counts1 = df['clarity'].value_counts().reset_index() 
    category_counts1.columns = ['clarity','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'clarity', y = 'Count', color= 'clarity', color_discrete_sequence=color_discrete_sequence, labels= {'clarity': 'clarity', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()
    
elif page1 == 'liczebność color':
    
    category_counts1 = df['color'].value_counts().reset_index() 
    category_counts1.columns = ['color','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'color', y = 'Count', color= 'color', color_discrete_sequence=color_discrete_sequence, labels= {'color': 'color', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show() 
    
           
elif page1 == 'liczebność cut':
    
    category_counts1 = df['cut'].value_counts().reset_index() 
    category_counts1.columns = ['cut','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'cut', y = 'Count', color= 'cut', color_discrete_sequence=color_discrete_sequence, labels= {'cut': 'cut', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()   

if page1 == 'liczebność x dimension':
    
    category_counts1 = df['x'].value_counts().reset_index() 
    category_counts1.columns = ['x','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'x', y = 'Count', color= 'x', color_continuous_scale = 'viridis', labels= {'x': 'x', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()
  
  
if page1 == 'liczebność y dimension':
    
    category_counts1 = df['y'].value_counts().reset_index() 
    category_counts1.columns = ['y','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'y', y = 'Count', color= 'y', color_continuous_scale = 'viridis', labels= {'y': 'y', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()  
       
if page1 == 'liczebność z dimension':
    
    category_counts1 = df['z'].value_counts().reset_index() 
    category_counts1.columns = ['z','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'z', y = 'Count', color= 'z', color_continuous_scale = 'viridis', labels= {'z': 'z', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()       

if page1 == 'liczebność depth':
    
    category_counts1 = df['depth'].value_counts().reset_index() 
    category_counts1.columns = ['depth','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'depth', y = 'Count', color= 'depth', color_continuous_scale = 'viridis', labels= {'depth': 'depth', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()       
    
if page1 == 'liczebność table':
    
    category_counts1 = df['table'].value_counts().reset_index() 
    category_counts1.columns = ['table','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1, x = 'table', y = 'Count', color= 'table', color_continuous_scale = 'viridis', labels= {'table': 'table', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()     
    
if page1 == 'liczebność price':
    
    category_counts1 = df['price'].value_counts().reset_index() 
    category_counts1.columns = ['price','Count']
    color_discrete_sequence = ['#ec7c23']*len(df)
    for i in range (len(df)):
      color_discrete_sequence[0] = '#FFFF00' 
      color_discrete_sequence[1] = '#CC0033'
      color_discrete_sequence[2] = '#FF66CC'
      color_discrete_sequence[3] = '#3300FF'
      color_discrete_sequence[2] = '#33CCCC'
      color_discrete_sequence[5] = '#00FF66'
      color_discrete_sequence[6] = '#434a11' 
      color_discrete_sequence[7] = '#CC0033'
      color_discrete_sequence[8] = '#CCFF00'
      color_discrete_sequence[9] = '#9933000'
      color_discrete_sequence[10] = '#FF3300'
      color_discrete_sequence[11] = '#32CD32'
      
      
    fig = px.bar(category_counts1,x = 'price', y = 'Count', color= 'price', color_continuous_scale = 'viridis', labels= {'price': 'price', 'Count' : 'liczebność'},
                 barmode='stack', text_auto=True ) 
    fig.update_traces(texttemplate='<b>%{y}</b>', textposition='outside')
    fig.show()    
   
